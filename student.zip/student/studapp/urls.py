from django.urls import path
from . import views
from django.contrib.auth import views as auth_views
urlpatterns = [
    path('',views.indexpage,name="index"),
    path('index/',views.index,name="index"),
    path('add/',views.add),
    path('logout/',views.logoutu),
    path('show/<int:id>',views.detailpage),
    path('delete/<int:id>',views.deletes),
    path('update/<int:id>',views.updatepage),
    path('login/',views.loginu,name='login'),
    path('reg/',views.reg),
    path('change/',views.PasswordsChangeView.as_view(template_name='change.html')),
    # path('password_change/done/', auth_views.PasswordChangeDoneView.as_view(), name='password_change_done'),
]
