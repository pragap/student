from django.db import models

# Create your models here.
class Studentinfo(models.Model):
    Rollno=models.IntegerField(primary_key = True)
    Name=models.CharField(max_length=150)
    Class=models.CharField(max_length=150)
    School=models.CharField(max_length=150,default='null')
    Mobile=models.CharField(max_length=10)
    Address=models.CharField(max_length=200)

class StudentAcademics(models.Model):
    Rollno=models.OneToOneField(Studentinfo,on_delete=models.CASCADE)
    Maths=models.IntegerField()
    Physics=models.IntegerField()
    Chemistry=models.IntegerField()
    Biology=models.IntegerField()
    English=models.IntegerField()

class user(models.Model):
    username=models.CharField(max_length=30)
    password=models.CharField(max_length=30)
    phone=models.CharField(max_length=30)
