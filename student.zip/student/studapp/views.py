from django.shortcuts import render,redirect
from .models import Studentinfo,StudentAcademics,user
from django.http import JsonResponse
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import PasswordChangeView
from django.urls import reverse_lazy
from django.contrib.auth.views import PasswordChangeForm
# Create your views here.
def indexpage(request):
    studentsinfo=Studentinfo.objects.all()
    print(studentsinfo)
    return render(request,'base.html',{"students":studentsinfo})

@login_required(login_url='/stud/')
def index(request):
    studentsinfo=Studentinfo.objects.all()
    print(studentsinfo)
    return render(request,'index.html',{"students":studentsinfo})

@login_required(login_url='/stud/')
def detailpage(request,id):
    studentd=StudentAcademics.objects.filter(Rollno=id)
    studentsinfo=Studentinfo.objects.filter(Rollno=id)
    print(studentd)
    return render(request,'detail.html',{"studentd":studentd,"name":studentsinfo.values('Name')})

def deletes(request,id):
    studentd=StudentAcademics.objects.filter(Rollno=id)
    studentsinfo=Studentinfo.objects.filter(Rollno=id)
    studentsinfo.delete()
    return redirect('/stud/')

@login_required(login_url='/stud/')
def updatepage(request,id):
    if request.method=="POST":
        roll=request.POST.get("rollnum")
        print(roll)
        name=request.POST.get("namestd")
        print(name)
        classval=request.POST.get("class")
        school=request.POST.get("school")
        phone=request.POST.get("mobile")
        address=request.POST.get("address")
        mat=request.POST.get("maths")
        phy=request.POST.get("phy")
        eng=request.POST.get("eng")
        bio=request.POST.get("bio")
        che=request.POST.get("che")
        studentsinfob=Studentinfo.objects.filter(Rollno=id)
        studentdob=StudentAcademics.objects.filter(Rollno=id)
        for studentsinfo in studentsinfob:
            studentsinfo.Rollno,studentsinfo.Name,studentsinfo.Mobile,studentsinfo.School,studentsinfo.Class,studentsinfo.Address=\
            roll,name,phone,school,classval,address
            studentsinfo.save()
        for studentd in studentdob:
            studentd.Maths,studentd.Physics,studentd.Chemistry,studentd.Biology,studentd.English,\
            =mat,phy,che,bio,eng
            studentd.save()
        return redirect('/stud/')
    else:
        studentd=StudentAcademics.objects.filter(Rollno=id)
        studentsinfo=Studentinfo.objects.filter(Rollno=id)
        return render(request,'update.html',{"student":studentsinfo,"marks":studentd})

@login_required(login_url='/stud/')
def add(request):
    if request.method=="POST":
        roll=request.POST.get("roll")
        name=request.POST.get("name")
        classval=request.POST.get("classval")
        school=request.POST.get("School")
        phone=request.POST.get("mobile")
        address=request.POST.get("address")
        mat=request.POST.get("math")
        phy=request.POST.get("phy")
        eng=request.POST.get("eng")
        bio=request.POST.get("bio")
        che=request.POST.get("che")
        if not Studentinfo.objects.filter(Rollno=roll, Mobile=phone).exists():
            a=Studentinfo(Rollno=roll,Name=name,Mobile=phone,School=school,Class=classval,Address=address)
            a.save()
            # StudentAcademics.Rollno=foren
            StudentAcademics(Maths=mat,Physics=phy,Chemistry=che,Biology=bio,English=eng,Rollno=a).save()
            return JsonResponse({"data":"student added"})
def loginu(request):
    if request.method=="POST":
        username=request.POST.get('username')
        password=request.POST.get('password')
        print(password)
        user = authenticate(request,username=username,password=password)
        print(user)
        if user is not None:
            print("uyessss")
            login(request,user)
            # studentsinfo=Studentinfo.objects.all()
            return redirect('/stud/index/')
        else:
            form=UserCreationForm()
            error="in valid credintals"
            return render(request,'login.html',{"form":form,"error":error})

    form=UserCreationForm()
    return render(request,'login.html',{"form":form})
@login_required(login_url='/stud/')
def logoutu(request):
    logout(request)
    return redirect('/stud/')

# @login_required(login_url='/stud/')
# def changep(request):
#     instance_user = get_object_or_404(User, id=int(user_id))
#     form=PasswordChangeForm()
#     return render(request,'change.html',{"form":form})
class PasswordsChangeView(PasswordChangeView):
    from_class=PasswordChangeForm
    success_url="/stud/login/"

def reg(request):
    if request.method=="POST":
        form=UserCreationForm(request.POST)
        if form.is_valid():
            user=form.save(commit=False)
            user.save()
            print(user)
            return redirect('/stud/')
        else:
            form=UserCreationForm()
            return render(request,'register.html',{"error":"enter details in correct format","form":form})

    form=UserCreationForm()
    return render(request,'register.html',{"form":form})
